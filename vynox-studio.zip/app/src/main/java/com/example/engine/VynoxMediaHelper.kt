package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object VynoxMediaHelper {
    private const val TAG = "VynoxMediaHelper"

    data class MediaInfo(
        val durationMs: Long,
        val width: Int,
        val height: Int,
        val isVideo: Boolean
    )

    suspend fun inspectMedia(context: Context, uri: Uri): MediaInfo = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val widthStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val heightStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)

            val durationMs = durationStr?.toLongOrNull() ?: 5000L
            val width = widthStr?.toIntOrNull() ?: 1080
            val height = heightStr?.toIntOrNull() ?: 1920
            val hasVideo = widthStr != null && heightStr != null

            MediaInfo(
                durationMs = if (durationMs > 0) durationMs else 5000L,
                width = width,
                height = height,
                isVideo = hasVideo
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error inspecting media: ${e.message}")
            MediaInfo(durationMs = 5000L, width = 1080, height = 1920, isVideo = false)
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    suspend fun getThumbnail(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val frame = retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            if (frame != null) {
                val thumbFile = File(context.cacheDir, "thumb_${UUID.randomUUID()}.jpg")
                FileOutputStream(thumbFile).use { out ->
                    frame.compress(Bitmap.CompressFormat.JPEG, 85, out)
                }
                return@withContext Uri.fromFile(thumbFile).toString()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not extract thumbnail: ${e.message}")
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
        null
    }

    /**
     * Generates a starter creative video clip or animated canvas card
     * so that the editor has real media out of the box even before importing from device gallery.
     */
    suspend fun generateSampleGraphic(
        context: Context,
        title: String,
        sub: String,
        bgGradientStart: Int,
        bgGradientEnd: Int
    ): Uri = withContext(Dispatchers.IO) {
        val width = 1080
        val height = 1920
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Gradient Background
        val paint = Paint().apply { isAntiAlias = true }
        for (y in 0 until height) {
            val fraction = y.toFloat() / height
            val r = (Color.red(bgGradientStart) * (1 - fraction) + Color.red(bgGradientEnd) * fraction).toInt()
            val g = (Color.green(bgGradientStart) * (1 - fraction) + Color.green(bgGradientEnd) * fraction).toInt()
            val b = (Color.blue(bgGradientStart) * (1 - fraction) + Color.blue(bgGradientEnd) * fraction).toInt()
            paint.color = Color.rgb(r, g, b)
            canvas.drawLine(0f, y.toFloat(), width.toFloat(), y.toFloat(), paint)
        }

        // Decorative geometric cards
        paint.color = Color.argb(40, 255, 255, 255)
        canvas.drawCircle(width * 0.5f, height * 0.45f, 320f, paint)
        paint.color = Color.argb(20, 0, 210, 255)
        canvas.drawCircle(width * 0.5f, height * 0.45f, 380f, paint)

        // Text
        val textPaint = Paint().apply {
            isAntiAlias = true
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = 72f
            isFakeBoldText = true
            setShadowLayer(16f, 0f, 8f, Color.argb(180, 0, 0, 0))
        }
        canvas.drawText(title, width / 2f, height * 0.45f, textPaint)

        textPaint.textSize = 38f
        textPaint.color = Color.rgb(0, 210, 255)
        textPaint.isFakeBoldText = false
        canvas.drawText(sub, width / 2f, height * 0.52f, textPaint)

        textPaint.textSize = 28f
        textPaint.color = Color.argb(160, 255, 255, 255)
        canvas.drawText("VYNOX STUDIO • 4K ULTRA HDR", width / 2f, height * 0.88f, textPaint)

        val sampleFile = File(context.cacheDir, "sample_${UUID.randomUUID()}.jpg")
        FileOutputStream(sampleFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        Uri.fromFile(sampleFile)
    }

    /**
     * Voice-over audio recorder helper using Android MediaRecorder
     */
    class VoiceRecorder(private val context: Context) {
        private var recorder: MediaRecorder? = null
        var outputFile: File? = null
            private set
        var isRecording: Boolean = false
            private set

        fun startRecording(): Boolean {
            return try {
                val file = File(context.cacheDir, "voice_${UUID.randomUUID()}.m4a")
                outputFile = file
                recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    MediaRecorder(context)
                } else {
                    @Suppress("DEPRECATION")
                    MediaRecorder()
                }.apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    setAudioEncodingBitRate(128000)
                    setAudioSamplingRate(44100)
                    setOutputFile(file.absolutePath)
                    prepare()
                    start()
                }
                isRecording = true
                true
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start audio recording: ${e.message}")
                outputFile?.delete()
                outputFile = null
                isRecording = false
                false
            }
        }

        fun stopRecording(): File? {
            return try {
                if (isRecording) {
                    recorder?.stop()
                    recorder?.release()
                    recorder = null
                    isRecording = false
                    outputFile
                } else null
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping recorder: ${e.message}")
                recorder?.release()
                recorder = null
                isRecording = false
                outputFile
            }
        }
    }
}
