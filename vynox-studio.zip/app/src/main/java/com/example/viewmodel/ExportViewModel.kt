package com.example.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ProjectRepository
import com.example.engine.VynoxExporter
import com.example.model.ExportFps
import com.example.model.ExportQuality
import com.example.model.ExportResolution
import com.example.model.ExportSettings
import com.example.model.VynoxProject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ExportViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ProjectRepository(application)
    private val exporter = VynoxExporter(application)

    private val _project = MutableStateFlow<VynoxProject?>(null)
    val project: StateFlow<VynoxProject?> = _project.asStateFlow()

    private val _settings = MutableStateFlow(ExportSettings())
    val settings: StateFlow<ExportSettings> = _settings.asStateFlow()

    private val _exportState = MutableStateFlow<VynoxExporter.ExportState>(VynoxExporter.ExportState.Idle)
    val exportState: StateFlow<VynoxExporter.ExportState> = _exportState.asStateFlow()

    fun loadProject(projectId: String) {
        viewModelScope.launch {
            _project.value = repository.getProject(projectId)
        }
    }

    fun setResolution(resolution: ExportResolution) {
        _settings.value = _settings.value.copy(resolution = resolution)
    }

    fun setFrameRate(fps: ExportFps) {
        _settings.value = _settings.value.copy(frameRate = fps)
    }

    fun setQuality(quality: ExportQuality) {
        _settings.value = _settings.value.copy(quality = quality)
    }

    fun calculateEstimatedSizeMb(): Float {
        val proj = _project.value ?: return 10f
        val durationSec = proj.totalDurationMs / 1000f
        val baseBitrateMbps = when (_settings.value.resolution) {
            ExportResolution.RES_480P -> 2.5f
            ExportResolution.RES_720P -> 5.0f
            ExportResolution.RES_1080P -> 10.0f
        }
        val fpsFactor = when (_settings.value.frameRate) {
            ExportFps.FPS_24 -> 0.9f
            ExportFps.FPS_30 -> 1.0f
            ExportFps.FPS_60 -> 1.5f
        }
        val qualityFactor = _settings.value.quality.bitrateMultiplier
        val totalBitsMb = durationSec * (baseBitrateMbps * fpsFactor * qualityFactor)
        return (totalBitsMb / 8f).coerceAtLeast(1.5f)
    }

    fun startExport() {
        val proj = _project.value ?: return
        viewModelScope.launch {
            exporter.exportProject(proj, _settings.value) { state ->
                _exportState.value = state
            }
        }
    }

    fun cancelExport() {
        exporter.cancelExport()
        _exportState.value = VynoxExporter.ExportState.Cancelled
    }

    fun shareVideo(uri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(intent, "Share Exported Video").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        getApplication<Application>().startActivity(chooser)
    }

    fun openVideo(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "video/mp4")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            getApplication<Application>().startActivity(intent)
        } catch (_: Exception) {}
    }
}
