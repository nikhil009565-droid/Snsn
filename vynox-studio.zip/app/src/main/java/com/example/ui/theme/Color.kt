package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val VynoxBlack = Color(0xFF0A0A0F)
val VynoxDarkSurface = Color(0xFF12111A)
val VynoxCardSurface = Color(0xFF181724)
val VynoxElevatedSurface = Color(0xFF222033)
val VynoxBorder = Color(0xFF2D2B42)

val VynoxPurple = Color(0xFFA855F7)
val VynoxPurpleDark = Color(0xFF7E22CE)
val VynoxPurpleGlow = Color(0xFFC084FC)
val VynoxElectricBlue = Color(0xFF00D2FF)
val VynoxBlueDark = Color(0xFF0284C7)

val VynoxAccentPink = Color(0xFFF43F5E)
val VynoxAccentGreen = Color(0xFF10B981)
val VynoxAccentAmber = Color(0xFFF59E0B)

val VynoxTextPrimary = Color(0xFFF8FAFC)
val VynoxTextSecondary = Color(0xFF94A3B8)
val VynoxTextMuted = Color(0xFF64748B)

val TimelineTrackBg = Color(0xFF14131E)
val TimelineRulerBg = Color(0xFF191826)
val TimelinePlayhead = Color(0xFF00D2FF)
val TimelineClipSelected = Color(0xFFA855F7)
